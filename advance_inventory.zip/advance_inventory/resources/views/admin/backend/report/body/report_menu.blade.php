<ul class="navbar-nav">
    <li class="nav-item">
        <a href="{{ route('all.report') }}" class="nav-link active" aria-current="page">Purchase</a>
    </li>
    <li class="nav-item">
        <a href="{{ route('purchase.return.report') }}" class="nav-link purchase-return-tab">Purchase Return</a>
    </li>
    <li class="nav-item">
        <a href="{{ route('sale.report') }}" class="nav-link">Sale</a>
    </li>
    <li class="nav-item">
        <a href="{{ route('sale.return.report') }}" class="nav-link">Sale Return</a>
    </li>
    <li class="nav-item">
        <a href="{{ route('product.stock.report') }}" class="nav-link">Stock</a>
    </li>
</ul>
