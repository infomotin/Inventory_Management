<?php $__env->startSection('admin'); ?>

<div class="content d-flex flex-column flex-column-fluid">
    <div class="d-flex flex-column-fluid">
        <div class="container-fluid my-0">
            <div class="py-3 d-flex align-items-sm-center flex-sm-row flex-column">
                <div class="flex-grow-1">
                    <h2 class="fs-22 fw-semibold m-0">Edit Product</h2>
                </div>

                <div class="text-end">
                    <ol class="breadcrumb m-0 py-0">
                        <a href="<?php echo e(route('all.product')); ?>" class="btn btn-dark">Back</a>
                    </ol>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <form action="<?php echo e(route('update.product')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($editData->id); ?>">

                        <div class="row">
                            <div class="col-xl-8">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Product Name: <span class="text-danger">*</span></label>
                                            <input type="text" name="name" placeholder="Enter Name" class="form-control" value="<?php echo e($editData->name); ?>">
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Code: <span class="text-danger">*</span></label>
                                            <input type="text" name="code" class=" form-control" value="<?php echo e($editData->code); ?>">

                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <div class="form-group w-100">
                                                <label class="form-label" for="formBasic">Product Category : <span class="text-danger">*</span></label>
                                                <select name="category_id" id="category_id" class="form-control form-select">
                                                    <option value="">Select Category</option>
                                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == $editData->category_id ? 'selected' : ''); ?>><?php echo e($item->category_name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>

                                            </div>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <div class="form-group w-100">
                                                <label class="form-label" for="formBasic">Brand : <span class="text-danger">*</span></label>
                                                <select name="brand_id" id="brand_id" class="form-control form-select">
                                                    <option value="">Select Brand</option>
                                                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == $editData->brand_id ? 'selected' : ''); ?>><?php echo e($item->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>

                                            </div>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Product Price: </label>
                                            <input type="text" name="price" class="form-control" value="<?php echo e($editData->price); ?>">

                                        </div>


                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Stock Alert: <span class="text-danger">*</span></label>
                                            <input type="number" name="stock_alert" class="form-control" value="<?php echo e($editData->stock_alert); ?>" min="0" required>

                                        </div>

                                        <div class="col-md-12">
                                            <label class="form-label">Notes: </label>
                                            <textarea class="form-control" name="note" rows="3" placeholder="Enter Notes"><?php echo e($editData->note); ?></textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-4">
                                <div class="card">
                                    <label class="form-label">Multiple Image: <span class="text-danger">*</span></label>
                                    <div class="mb-3">
                                        <input name="image[]" accept=".png, .jpg, .jpeg" multiple="" type="file" id="multiImg" class="upload-input-file form-control">
                                    </div>

                                    <div class="row" id="preview_img">
                                        <?php if(isset($editData) && $editData->images->count() > 0): ?>
                                        <?php $__currentLoopData = $editData->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-3 mb-2">
                                            <img src="<?php echo e(asset($img->image)); ?>" alt="Product image" class="img-thumbnail">

                                            <div class="form-check mt-1">
                                                <input class="form-check-input" type="checkbox" name="remove_image[]" value="<?php echo e($img->id); ?>" id="remove_image_<?php echo e($img->id); ?>">
                                                <label for="remove_image_<?php echo e($img->id); ?>" class="form-check-label">Remove</label>
                                            </div>

                                        </div>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <?php endif; ?>


                                    </div>
                                </div>
                                <div>
                                    <div class="col-md-12 mb-3">
                                        <h4 class="text-center">Add Stock : </h4>
                                    </div>
                                    <div class="col-md-12 mb-3">
                                        <div class="form-group w-100">
                                            <label class="form-label" for="formBasic">Warehouse : <span class="text-danger">*</span></label>
                                            <select name="warehouse_id" id="warehouse_id" class="form-control form-select">
                                                <option value="">Select Warehouse</option>
                                                <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == $editData->warehouse_id ? 'selected' : ''); ?>><?php echo e($item->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>

                                        </div>
                                    </div>
                                    <div class="col-md-12 mb-3">
                                        <div class="form-group w-100">
                                            <label class="form-label" for="formBasic">Supplier : <span class="text-danger">*</span></label>
                                            <select name="supplier_id" id="supplier_id" class="form-control form-select">
                                                <option value="">Select Supplier</option>
                                                <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == $editData->supplier_id ? 'selected' : ''); ?>><?php echo e($item->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>

                                        </div>
                                    </div>

                                    <div class="col-md-12 mb-3">
                                        <label class="form-label">Product Quantity: <span class="text-danger">*</span></label>
                                        <input type="number" name="product_qty" class="form-control" value="<?php echo e($editData->product_qty); ?>" min="1" required>

                                    </div>

                                    <div class="col-md-12">
                                        <div class="form-group w-100">
                                            <label class="form-label" for="formBasic">Status : <span class="text-danger">*</span></label>
                                            <select name="status" id="status" class="form-control form-select">
                                                <option selected="">Select Status</option>

                                                <option value="Received" <?php echo e((isset($editData->status ) && $editData->status == 'Received' ) ? 'selected' : ''); ?>>Received</option>

                                                <option value="Pending" <?php echo e((isset($editData->status ) && $editData->status == 'Pending' ) ? 'selected' : ''); ?>>Pending</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-12">
                                <div class="d-flex mt-5 justify-content-start">
                                    <button class="btn btn-primary me-3" type="submit">Save</button>
                                    <a class="btn btn-secondary" href="<?php echo e(route('all.product')); ?>">Cancel</a>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\Inventory_Management\advance_inventory\resources\views\admin\backend\product\edit_product.blade.php ENDPATH**/ ?>