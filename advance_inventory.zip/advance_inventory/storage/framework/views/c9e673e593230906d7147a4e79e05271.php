<?php $__env->startSection('admin'); ?>

<div class="page-content m-2">
    <div class="container">
        <?php echo $__env->make('admin.backend.report.body.report_top', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
    

    <div class="card">

        <nav class="navbar navbar-expand-lg bg-dark">
            <div class="container-fluid">
                <div class="collapse navbar-collapse" id="navbarNav">
                    <?php echo $__env->make('admin.backend.report.body.report_menu', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>



            </div>
        </nav>

        <div class="card-body">
            <div class="table-responsive">
                <div id="example_wrapper" class="dataTables_wrapper dt-bootstrap5">
                    <div class="row">
                        <div class="col-sm-12">
                            <table id="example" class="table table-striped table-bordered dataTable" style="width: 100%;" role="grid" aria-describedby="example_info">
                                <thead>
                                    <tr role="row">
                                        <th>ID</th>
                                        <th>Date</th>
                                        <th>Customer</th>
                                        <th>Warehouse</th>
                                        <th>Product</th>
                                        <th>Quantity</th>
                                        <th>Unti Price</th>
                                        <th>Status</th>
                                        <th>Grand Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $returnSales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $sales): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $sales->saleReturnItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key+1); ?></td>
                                        <td><?php echo e($sales->date); ?></td>
                                        <td><?php echo e($sales->customer->name ?? 'N/A'); ?></td>
                                        <td><?php echo e($sales->warehouse->name ?? 'N/A'); ?></td>
                                        <td><?php echo e($item->product->name ?? 'N/A'); ?></td>
                                        <td><?php echo e($item->quantity ?? 'N/A'); ?></td>
                                        <td><?php echo e($item->net_unit_cost ?? 'N/A'); ?></td>
                                        <td><?php echo e($sales->status ?? 'N/A'); ?></td>
                                        <td><?php echo e($sales->grand_total ?? 'N/A'); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>

                            </table>

                        </div>

                    </div>

                </div>

            </div>
        </div>





    </div>
    

</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\Inventory_Management\advance_inventory\resources\views\admin\backend\report\sales_return_report.blade.php ENDPATH**/ ?>