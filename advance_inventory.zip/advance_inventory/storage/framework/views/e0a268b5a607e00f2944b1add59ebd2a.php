<?php $__env->startSection('admin'); ?>
    <div class="content">

        <!-- Start Content-->
        <div class="container-xxl">

            <div class="py-3 d-flex align-items-sm-center flex-sm-row flex-column">
                <div class="flex-grow-1">
                    <h4 class="fs-18 fw-semibold m-0">All Sales</h4>
                </div>

                <div class="text-end">
                    <ol class="breadcrumb m-0 py-0">
                        <a href="<?php echo e(route('add.sale')); ?>" class="btn btn-secondary">Add Sales</a>
                    </ol>
                </div>
            </div>

            <!-- Datatables  -->
            <div class="row">
                <div class="col-12">
                    <div class="card">

                        <div class="card-header">

                        </div><!-- end card header -->

                        <div class="card-body">
                            <table id="datatable" class="table table-bordered dt-responsive table-responsive nowrap">
                                <thead>
                                    <tr>
                                        <th>Sl</th>
                                        <th>WareHouse</th>
                                        <th>Status</th>
                                        <th>Grand Total</th>
                                        <th>Paid Amount</th>
                                        <th>Due Amount</th>
                                        <th>Created</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $allData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($key + 1); ?></td>
                                            <td><?php echo e($item['warehouse']['name']); ?></td>
                                            <td><?php echo e($item->status); ?></td>
                                            <td>$<?php echo e($item->grand_total); ?></td>
                                            <td>
                                                <h4> <span class="badge text-bg-info">$<?php echo e($item->paid_amount); ?> </span>
                                                </h4>
                                            </td>
                                            <td>
                                                <h4> <span class="badge text-bg-secondary">$<?php echo e($item->due_amount); ?> </span>
                                                </h4>
                                            </td>
                                            <td><?php echo e(\Carbon\Carbon::parse($item->created_at)->format('Y-m-d')); ?></td>
                                            <td>
                                                <a title="Details" href="<?php echo e(route('details.sale', $item->id)); ?>"
                                                    class="btn btn-info btn-sm"> <span
                                                        class="mdi mdi-eye-circle mdi-18px"></span> </a>

                                                <a title="PDF Invoice" href="<?php echo e(route('invoice.sale', $item->id)); ?>"
                                                    class="btn btn-primary btn-sm"> <span
                                                        class="mdi mdi-download-circle mdi-18px"></span> </a>

                                                <a title="Edit" href="<?php echo e(route('edit.sale', $item->id)); ?>"
                                                    class="btn btn-success btn-sm"> <span
                                                        class="mdi mdi-book-edit mdi-18px"></span> </a>

                                                <a title="Delete" href="<?php echo e(route('delete.sale', $item->id)); ?>"
                                                    class="btn btn-danger btn-sm" id="delete"><span
                                                        class="mdi mdi-delete-circle  mdi-18px"></span></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>




        </div> <!-- container-fluid -->

    </div> <!-- content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\Inventory_Management\advance_inventory\resources\views\admin\backend\sales\all_sales.blade.php ENDPATH**/ ?>