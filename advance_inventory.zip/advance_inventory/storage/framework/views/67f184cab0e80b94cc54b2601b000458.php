<?php $__env->startSection('admin'); ?>
    <div class="content">

        <!-- Start Content-->
        <div class="container-xxl">

            <div class="py-3 d-flex align-items-sm-center flex-sm-row flex-column">
                <div class="flex-grow-1">
                    <h4 class="fs-18 fw-semibold m-0">All Transfer </h4>
                </div>

                <div class="text-end">
                    <ol class="breadcrumb m-0 py-0">
                        <a href="<?php echo e(route('add.transfer')); ?>" class="btn btn-secondary">Add Transfer</a>
                    </ol>
                </div>
            </div>

            <!-- Datatables  -->
            <div class="row">
                <div class="col-12">
                    <div class="card">

                        <div class="card-header">

                        </div><!-- end card header -->

                        <div class="card-body">
                            <table id="datatable" class="table table-bordered dt-responsive table-responsive nowrap">
                                <thead>
                                    <tr>
                                        <th>Sl</th>
                                        <th>Date</th>
                                        <th>From WareHouse</th>
                                        <th>To WareHouse</th>
                                        <th>Product</th>
                                        <th>Stock Transfer</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $allData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($key + 1); ?></td>
                                            <td><?php echo e(\Carbon\Carbon::parse($item->date)->format('Y-m-d')); ?></td>
                                            <td><?php echo e($item['fromWarehouse']['name']); ?></td>
                                            <td><?php echo e($item['toWarehouse']['name']); ?></td>
                                            <td>
                                                <?php $__currentLoopData = $item->transferItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transferItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php echo e($transferItem->product->name ?? 'N/A'); ?> <br>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>

                                            <td>
                                                <?php $__currentLoopData = $item->transferItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transferItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <h4> <span
                                                            class="badge text-bg-info"><?php echo e($transferItem->quantity); ?></span>
                                                    </h4>
                                                    <br>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>

                                            <td>
                                                <a title="Details" href="<?php echo e(route('details.transfer', $item->id)); ?>"
                                                    class="btn btn-info btn-sm"> <span
                                                        class="mdi mdi-eye-circle mdi-18px"></span> </a>

                                                <a title="Edit" href="<?php echo e(route('edit.transfer', $item->id)); ?>"
                                                    class="btn btn-success btn-sm"> <span
                                                        class="mdi mdi-book-edit mdi-18px"></span> </a>

                                                <a title="Delete" href="<?php echo e(route('delete.transfer', $item->id)); ?>"
                                                    class="btn btn-danger btn-sm" id="delete"><span
                                                        class="mdi mdi-delete-circle  mdi-18px"></span></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>




        </div> <!-- container-fluid -->

    </div> <!-- content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\Inventory_Management\advance_inventory\resources\views/admin/backend/transfer/all_transfer.blade.php ENDPATH**/ ?>