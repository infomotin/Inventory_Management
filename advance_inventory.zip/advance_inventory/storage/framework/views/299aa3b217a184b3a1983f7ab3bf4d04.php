


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Purchase Invoice</title>
    <style>
        /* Base Styles */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-size: 14px;
            line-height: 1.6;
            color: #333;
            background-color: #fff;
            margin: 0;
            padding: 20px;
        }

        /* Header Section */
        .invoice-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f0f0f0;
        }

        .invoice-title {
            font-size: 24px;
            font-weight: 700;
            color: #2c3e50;
            margin: 0;
        }

        .invoice-number {
            font-size: 14px;
            color: #7f8c8d;
            margin-top: 5px;
        }

        .company-logo {
            max-height: 70px;
        }

        /* Info Sections */
        .info-section {
            display: flex;
            justify-content: space-between;
            margin-bottom: 30px;
        }

        .info-box {
            flex: 1;
            padding: 15px;
            background-color: #f9f9f9;
            border-radius: 6px;
            margin: 0 10px;
        }

        .info-box:first-child {
            margin-left: 0;
        }

        .info-box:last-child {
            margin-right: 0;
        }

        .info-box h3 {
            margin-top: 0;
            color: #2c3e50;
            font-size: 16px;
            padding-bottom: 8px;
            border-bottom: 1px solid #eee;
        }

        /* Table Styles */
        .table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            font-size: 13px;
        }

        .table th {
            background-color: #f8f9fa;
            padding: 12px 10px;
            text-align: left;
            font-weight: 600;
            color: #2c3e50;
            border: 1px solid #dee2e6;
        }

        .table td {
            padding: 12px 10px;
            border: 1px solid #dee2e6;
            vertical-align: top;
        }

        .table tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .table tbody tr:hover {
            background-color: #f1f1f1;
        }

        /* Summary Section */
        .summary-section {
            margin-top: 30px;
            display: flex;
            justify-content: flex-end;
        }

        .summary-table {
            width: 300px;
            border-collapse: collapse;
        }

        .summary-table td {
            padding: 10px 15px;
            border: 1px solid #dee2e6;
        }

        .summary-table .label {
            font-weight: 600;
            background-color: #f8f9fa;
        }

        .summary-table .total {
            font-weight: 700;
            font-size: 15px;
            color: #2c3e50;
            background-color: #f0f7ff;
        }

        /* Status Badge */
        .status-badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .status-received {
            background-color: #d4edda;
            color: #155724;
        }

        .status-pending {
            background-color: #fff3cd;
            color: #856404;
        }

        .status-ordered {
            background-color: #cce5ff;
            color: #004085;
        }

        /* Utility Classes */
        .text-right {
            text-align: right;
        }

        .text-center {
            text-align: center;
        }

        .text-bold {
            font-weight: 600;
        }

        .mb-0 {
            margin-bottom: 0;
        }

        .mt-0 {
            margin-top: 0;
        }

        .mt-20 {
            margin-top: 20px;
        }

        .p-0 {
            padding: 0;
        }

        /* Footer */
        .footer {
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #eee;
            text-align: center;
            color: #7f8c8d;
            font-size: 12px;
        }

        /* Print Styles */
        @media print {
            body {
                padding: 0;
                font-size: 12px;
            }

            .no-print {
                display: none !important;
            }

            .table th {
                background-color: #f8f9fa !important;
                -webkit-print-color-adjust: exact;
            }

            .summary-table .label {
                background-color: #f8f9fa !important;
                -webkit-print-color-adjust: exact;
            }
        }
    </style>
</head>

<body>
    <div class="invoice-header">
        <div>
            <h1 class="invoice-title">PURCHASE INVOICE</h1>
            <div class="invoice-number">#<?php echo e(str_pad($purchase->id, 6, '0', STR_PAD_LEFT)); ?></div>
        </div>
        <img src="<?php echo e(public_path('backend/assets/images/logo/logo.png')); ?>" alt="Company Logo" class="company-logo">
    </div>

    <div class="info-section">
        <div class="info-box">
            <h3>Supplier Information</h3>
            <div class="text-bold"><?php echo e($purchase->supplier->name); ?></div>
            <div><?php echo e($purchase->supplier->email); ?></div>
            <div><?php echo e($purchase->supplier->phone); ?></div>
            <div><?php echo e($purchase->supplier->address); ?></div>
        </div>

        <div class="info-box">
            <h3>Company Information</h3>
            <div class="text-bold"><?php echo e(config('app.name')); ?></div>
            <div><?php echo e($purchase->warehouse->name); ?> Warehouse</div>
            <div>Invoice Date: <?php echo e(\Carbon\Carbon::parse($purchase->date)->format('M d, Y')); ?></div>
            <div>Status:
                <?php
                    $statusClass =
                        [
                            'Received' => 'status-received',
                            'Pending' => 'status-pending',
                            'Ordered' => 'status-ordered',
                        ][$purchase->status] ?? 'status-pending';
                ?>
                <span class="status-badge <?php echo e($statusClass); ?>"><?php echo e($purchase->status); ?></span>
            </div>
        </div>
    </div>

    <table class="table">
        <thead>
            <tr>
                <th>#</th>
                <th>Product</th>
                <th class="text-center">Qty</th>
                <th class="text-right">Unit Price</th>
                <th class="text-right">Discount</th>
                <th class="text-right">Total</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $purchase->purchaseItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td>
                        <div class="text-bold"><?php echo e($item->product->name); ?></div>
                        <div style="color: #7f8c8d; font-size: 12px;"><?php echo e($item->product->code); ?></div>
                    </td>
                    <td class="text-center"><?php echo e($item->quantity); ?></td>
                    <td class="text-right">$<?php echo e(number_format($item->net_unit_cost, 2)); ?></td>
                    <td class="text-right">$<?php echo e(number_format($item->discount, 2)); ?></td>
                    <td class="text-right">$<?php echo e(number_format($item->subtotal, 2)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="summary-section">
        <table class="summary-table">
            <tr>
                <td class="label">Subtotal</td>
                <td class="text-right">
                    $<?php echo e(number_format($purchase->grand_total - $purchase->shipping + $purchase->discount, 2)); ?></td>
            </tr>
            <?php if($purchase->discount > 0): ?>
                <tr>
                    <td class="label">Discount</td>
                    <td class="text-right">-$<?php echo e(number_format($purchase->discount, 2)); ?></td>
                </tr>
            <?php endif; ?>
            <?php if($purchase->shipping > 0): ?>
                <tr>
                    <td class="label">Shipping</td>
                    <td class="text-right">$<?php echo e(number_format($purchase->shipping, 2)); ?></td>
                </tr>
            <?php endif; ?>
            <tr>
                <td class="label total">Grand Total</td>
                <td class="text-right total">$<?php echo e(number_format($purchase->grand_total, 2)); ?></td>
            </tr>
        </table>
    </div>

    <?php if($purchase->note): ?>
        <div class="mt-20" style="padding: 15px; background-color: #f9f9f9; border-radius: 6px;">
            <div class="text-bold" style="margin-bottom: 8px;">Notes:</div>
            <div class="mb-0"><?php echo e($purchase->note); ?></div>
        </div>
    <?php endif; ?>

    <div class="footer">
        <div>Thank you for your business!</div>
        <div><?php echo e(config('app.name')); ?> | <?php echo e(config('app.url')); ?></div>
    </div>
</body>

</html>
<?php /**PATH D:\laragon\www\Inventory_Management\advance_inventory\resources\views\admin\backend\purchase\invoice_pdf.blade.php ENDPATH**/ ?>