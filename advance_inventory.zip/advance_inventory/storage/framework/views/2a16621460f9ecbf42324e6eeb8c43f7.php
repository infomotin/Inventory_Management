<?php $__env->startSection('admin'); ?>

<div class="content d-flex flex-column flex-column-fluid">
    <div class="d-flex flex-column-fluid">
        <div class="container-fluid my-4">
            <div class="d-md-flex align-items-center justify-content-between">
                <h3 class="mb-0"> Sales Return Details</h3>
                <div class="text-end my-2 mt-md-0"><a class="btn btn-outline-primary" href="<?php echo e(route('all.sale.return')); ?>">Back</a></div>
            </div>


            <div class="card">
                <div class="card-body">
                    <div class="row">

                        
                        <div class="col-md-4 mb-4">
                            <div class="card shadow-sm border-0 h-100" style="border-radius: 10px; transition: 0.2s">
                                <div class="card-header text-white text-center" style="background: linear-gradient(135deg, #17a2b8, #0d6efd); border-radius:10px 10px 0 0;">
                                    <h5 class="mb-0 fw-bold">Customer Information</h5>
                                </div>
                                <div class="card-body p-4">
                                    <div class="d-flex align-items-center mb-3">
                                        <strong class="me-2 text-muted">Name:</strong>
                                        <span><?php echo e($sales->customer->name); ?></span>
                                    </div>
                                    <div class="d-flex align-items-center mb-3">
                                        <strong class="me-2 text-muted">Email:</strong>
                                        <span><?php echo e($sales->customer->email); ?></span>
                                    </div>
                                    <div class="d-flex align-items-center mb-3">
                                        <strong class="me-2 text-muted">Phone:</strong>
                                        <span><?php echo e($sales->customer->phone); ?></span>
                                    </div>
                                </div>

                            </div>
                        </div>
                        


                        
                        <div class="col-md-4 mb-4">
                            <div class="card shadow-sm border-0 h-100" style="border-radius: 10px; transition: 0.2s">
                                <div class="card-header text-white text-center" style="background: linear-gradient(135deg, #17a2b8, #0d6efd); border-radius:10px 10px 0 0;">
                                    <h5 class="mb-0 fw-bold">Warehouse Information</h5>
                                </div>
                                <div class="card-body p-4">
                                    <div class="d-flex align-items-center mb-3">
                                        <strong class="me-2 text-muted">Warehouse:</strong>
                                        <span><?php echo e($sales->warehouse->name); ?></span>
                                    </div>

                                </div>

                            </div>
                        </div>
                        


                        
                        <div class="col-md-4 mb-4">
                            <div class="card shadow-sm border-0 h-100" style="border-radius: 10px; transition: 0.2s">
                                <div class="card-header text-white text-center" style="background: linear-gradient(135deg, #17a2b8, #0d6efd); border-radius:10px 10px 0 0;">
                                    <h5 class="mb-0 fw-bold">Sales Information</h5>
                                </div>
                                <div class="card-body p-4">
                                    <div class="d-flex align-items-center mb-3">
                                        <strong class="me-2 text-muted">Sales Date:</strong>
                                        <span><?php echo e($sales->date); ?></span>
                                    </div>
                                    <div class="d-flex align-items-center mb-3">
                                        <strong class="me-2 text-muted">Status:</strong>
                                        <span><?php echo e($sales->status); ?></span>
                                    </div>
                                    <div class="d-flex align-items-center mb-3">
                                        <strong class="me-2 text-muted">Paid Amount:</strong>
                                        <span><?php echo e($sales->paid_amount); ?></span>
                                    </div>
                                    <div class="d-flex align-items-center mb-3">
                                        <strong class="me-2 text-muted">Due Amount:</strong>
                                        <span><?php echo e($sales->due_amount); ?></span>
                                    </div>
                                    <div class="d-flex align-items-center mb-3">
                                        <strong class="me-2 text-muted">Grand Total:</strong>
                                        <span><?php echo e(number_format($sales->grand_total, 2)); ?></span>
                                    </div>
                                </div>

                            </div>
                        </div>
                        

                        
                        <div class="row mt-4">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card shadow-sm border-0 h-100" style="border-radius: 10px; transition: 0.2s">
                                        <div class="card-header text-white text-center" style="background: linear-gradient(135deg, #17a2b8, #0d6efd); border-radius:10px 10px 0 0;">
                                            <h5 class="mb-0 fw-bold">Order Summary</h5>
                                        </div>


                                        <div class="card-body">
                                            <table class="table table-bordered">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Product Name</th>
                                                        <th>Quantity</th>
                                                        <th>Net Unit Cost</th>
                                                        <th>Discount</th>
                                                        <th>Subtotal</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $sales->saleReturnItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($key + 1); ?></td>
                                                        <td><?php echo e($item->product->name); ?></td>
                                                        <td><?php echo e($item->quantity); ?></td>
                                                        <td><?php echo e(number_format($item->net_unit_cost,2)); ?></td>
                                                        <td><?php echo e(number_format($item->discount,2)); ?></td>
                                                        <td><?php echo e(number_format($item->subtotal,2)); ?></td>
                                                    </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>


                                    </div>
                                </div>
                            </div>
                        </div>


                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\Inventory_Management\advance_inventory\resources\views\admin\backend\return-sale\sales_return_details.blade.php ENDPATH**/ ?>