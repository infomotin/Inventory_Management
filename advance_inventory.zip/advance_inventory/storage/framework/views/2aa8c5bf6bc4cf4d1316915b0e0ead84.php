<ul class="navbar-nav">
    <li class="nav-item">
        <a href="<?php echo e(route('all.report')); ?>" class="nav-link active" aria-current="page">Purchase</a>
    </li>
    <li class="nav-item">
        <a href="<?php echo e(route('purchase.return.report')); ?>" class="nav-link purchase-return-tab">Purchase Return</a>
    </li>
    <li class="nav-item">
        <a href="<?php echo e(route('sale.report')); ?>" class="nav-link">Sale</a>
    </li>
    <li class="nav-item">
        <a href="<?php echo e(route('sale.return.report')); ?>" class="nav-link">Sale Return</a>
    </li>
    <li class="nav-item">
        <a href="<?php echo e(route('product.stock.report')); ?>" class="nav-link">Stock</a>
    </li>
</ul>
<?php /**PATH D:\laragon\www\Inventory_Management\advance_inventory\resources\views\admin\backend\report\body\report_menu.blade.php ENDPATH**/ ?>