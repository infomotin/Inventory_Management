<?php $__env->startSection('admin'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

<div class="content">

    <!-- Start Content-->
    <div class="container-xxl">

        <div class="py-3 d-flex align-items-sm-center flex-sm-row flex-column">
            <div class="flex-grow-1">
                <h4 class="fs-18 fw-semibold m-0">Add Roles</h4>
            </div>

            <div class="text-end">
                <ol class="breadcrumb m-0 py-0">

                    <li class="breadcrumb-item active">Add Roles</li>
                </ol>
            </div>
        </div>

        <!-- Form Validation -->
        <div class="row">
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Add Roles</h5>
                    </div><!-- end card header -->

                    <div class="card-body">
                        <form action="<?php echo e(route('store.roles')); ?>" method="post" class="row g-3" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <div class="col-md-6">
                                <label for="validationDefault01" class="form-label">Roles Name</label>
                                <input type="text" class="form-control" name="name">
                            </div>


                            <div class="col-12">
                                <button class="btn btn-primary" type="submit">Save Change</button>
                            </div>
                        </form>
                    </div> <!-- end card-body -->
                </div> <!-- end card-->
            </div> <!-- end col -->


        </div>



    </div> <!-- container-fluid -->

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\Inventory_Management\advance_inventory\resources\views\admin\backend\pages\role\add_role.blade.php ENDPATH**/ ?>