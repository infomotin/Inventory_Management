<?php $__env->startSection('admin'); ?>

<div class="page-content m-2">
    <div class="container">
        <?php echo $__env->make('admin.backend.report.body.report_top', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
    

    <div class="card">

        <nav class="navbar navbar-expand-lg bg-dark">
            <div class="container-fluid">
                <div class="collapse navbar-collapse" id="navbarNav">

                    <?php echo $__env->make('admin.backend.report.body.report_menu', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                </div>

                
                <div class="row">
                    <div class="col-md-12 d-flex align-items-center position-relative">
                        <select id="date-range" class="form-control large-select">
                            <option value="" selected disabled>Select Date Range</option>
                            <option value="today">Today</option>
                            <option value="this_week">This Week</option>
                            <option value="last_week">Last Week</option>
                            <option value="this_month">This Month</option>
                            <option value="last_month">Last Month</option>
                            <option value="custom">Custom Range</option>
                        </select>

                    </div>

                    
                    <div class="dropdown-menu p-3 custom-dropdown position-absolute shadow bg-white">
                        <label for="custom-start-date">Start Date:</label>
                        <input type="date" id="custom-start-date" class="form-control mb-2">

                        <label for="custom-end-date">End Date:</label>
                        <input type="date" id="custom-end-date" class="form-control mb-2">

                        <button id="apply-filter" class="btn btn-primary w-100">Apply</button>
                    </div>
                </div>
                


            </div>
        </nav>

        <div class="card-body">
            <div class="table-responsive">
                <div id="example_wrapper" class="dataTables_wrapper dt-bootstrap5">
                    <div class="row">
                        <div class="col-sm-12">
                            <table id="example" class="table table-striped table-bordered dataTable" style="width: 100%;" role="grid" aria-describedby="example_info">
                                <thead>
                                    <tr role="row">
                                        <th>ID</th>
                                        <th>Date</th>
                                        <th>Supplier</th>
                                        <th>Warehouse</th>
                                        <th>Product</th>
                                        <th>Quantity</th>
                                        <th>Unti Price</th>
                                        <th>Status</th>
                                        <th>Grand Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $purchase->purchaseItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key+1); ?></td>
                                        <td><?php echo e($purchase->date); ?></td>
                                        <td><?php echo e($purchase->supplier->name ?? 'N/A'); ?></td>
                                        <td><?php echo e($purchase->warehouse->name ?? 'N/A'); ?></td>
                                        <td><?php echo e($item->product->name ?? 'N/A'); ?></td>
                                        <td><?php echo e($item->quantity ?? 'N/A'); ?></td>
                                        <td><?php echo e($item->net_unit_cost ?? 'N/A'); ?></td>
                                        <td><?php echo e($purchase->status ?? 'N/A'); ?></td>
                                        <td><?php echo e($purchase->grand_total ?? 'N/A'); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>

                            </table>

                        </div>

                    </div>

                </div>

            </div>
        </div>





    </div>
    

</div>

<style>
    /* Ensure the navbar container is a positioning context */
    .navbar .container-fluid {
        position: relative;
    }

    /* Style the filter container */
    .filter-container {
        position: relative;
        display: inline-block;
        width: 200px;
        /* Adjust width to fit the select */
        margin-left: 10px;
    }

    /* Style the select element */
    .large-select {
        background-color: #343a40;
        /* Match navbar background */
        color: white;
        border: 1px solid #495057;
        padding: 5px 10px;
        width: 100%;
        appearance: none;
        /* Remove default dropdown arrow */
        -webkit-appearance: none;
        -moz-appearance: none;
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='white'%3E%3Cpath d='M7 10l5 5 5-5H7z'/%3E%3C/svg%3E");
        background-repeat: no-repeat;
        background-position: right 10px center;
        background-size: 12px;
    }

    /* Style the filter icon */
    .mdi-filter-menu {
        position: absolute;
        right: 30px;
        top: 50%;
        transform: translateY(-50%);
        color: white;
        pointer-events: none;
        /* Prevent icon from interfering with select */
    }

    /* Style the custom dropdown */
    .custom-dropdown {
        display: none;
        /* Initially hidden */
        position: absolute;
        top: 100%;
        /* Position below the select */
        right: 0;
        /* Align to the right of the filter container */
        width: 250px;
        /* Fixed width for consistency */
        background-color: #fff;
        border: 1px solid #ddd;
        border-radius: 4px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        z-index: 1000;
        /* Ensure it appears above other elements */
    }

    /* Ensure the dropdown fits within the navbar on smaller screens */
    @media (max-width: 991px) {
        .filter-container {
            width: 100%;
            margin-top: 10px;
        }

        .custom-dropdown {
            right: auto;
            left: 0;
            width: 100%;
        }
    }
</style>


<script>
    document.getElementById("date-range").addEventListener("change", function() {
        let selectedValue = this.value;
        let today = new Date();
        let startDate, endDate;

        if (selectedValue === "custom") {
            document.querySelector('.custom-dropdown').style.display = "block";
            return;
        } else {
            document.querySelector('.custom-dropdown').style.display = "none";
        }

        switch (selectedValue) {
            case "today":
                startDate = formatDate(today);
                endDate = formatDate(today);
                break;
            case "this_week":
                startDate = formatDate(getWeekStart(today));
                endDate = formatDate(today);
                break;
            case "last_week":
                let lastWeekStart = new Date(getWeekStart(today));
                lastWeekStart.setDate(lastWeekStart.getDate() - 7);
                let lastWeekEnd = new Date(lastWeekStart);
                lastWeekEnd.setDate(lastWeekStart.getDate() + 6);
                startDate = formatDate(lastWeekStart);
                endDate = formatDate(lastWeekEnd);
                break;
            case "this_month":
                startDate = formatDate(new Date(today.getFullYear(), today.getMonth(), 1));
                endDate = formatDate(today);
                break;
            case "last_month":
                let lastMonthStart = new Date(today.getFullYear(), today.getMonth() - 1, 1);
                let lastMonthEnd = new Date(today.getFullYear(), today.getMonth(), 0);
                startDate = formatDate(lastMonthStart);
                endDate = formatDate(lastMonthEnd);
                break;
            default:
                return;
        }

        // Fetch data via AJAX
        fetchFilteredData(startDate, endDate);
    });

    document.getElementById("apply-filter").addEventListener("click", function() {
        let startDate = document.getElementById("custom-start-date").value;
        let endDate = document.getElementById("custom-end-date").value;

        if (startDate && endDate) {
            fetchFilteredData(startDate, endDate);
        } else {
            alert("Please select both start and end dates.");
        }
    });

    function fetchFilteredData(startDate, endDate) {
        fetch(`/filter-purchases?start_date=${startDate}&end_date=${endDate}`, {
                headers: {
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(response => response.json())
            .then(data => {
                updateTable(data.purchases);
            })
            .catch(error => console.error('Error fetching data:', error));
    }

    function updateTable(purchases) {
        let tbody = document.querySelector("#example tbody");
        tbody.innerHTML = ""; // Clear existing rows

        purchases.forEach(purchase => {
            purchase.purchase_items.forEach(item => {
                // Ensure net_unit_cost is a number, default to 0 if null/undefined
                const netUnitCost = item.net_unit_cost ? parseFloat(item.net_unit_cost) : 0;

                let row = `
                    <tr>
                        <td>${purchase.id}</td>
                        <td>${purchase.date}</td>
                        <td>${purchase.supplier ? purchase.supplier.name : 'N/A'}</td>
                        <td>${purchase.warehouse ? purchase.warehouse.name : 'N/A'}</td>
                        <td>${item.product ? item.product.name : 'N/A'}</td>
                        <td>${item.quantity}</td>
                        <td>${netUnitCost.toFixed(2)}</td> <!-- Use the validated number -->
                        <td>${purchase.status}</td>
                        <td>${purchase.grand_total ? parseFloat(purchase.grand_total).toFixed(2) : '0.00'}</td>
                    </tr>
                `;
                tbody.insertAdjacentHTML('beforeend', row);
            });
        });
    }

    function formatDate(date) {
        return date.toISOString().split("T")[0];
    }

    function getWeekStart(date) {
        let d = new Date(date);
        d.setDate(d.getDate() - d.getDay());
        return d;
    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\Inventory_Management\advance_inventory\resources\views/admin/backend/report/all_report.blade.php ENDPATH**/ ?>